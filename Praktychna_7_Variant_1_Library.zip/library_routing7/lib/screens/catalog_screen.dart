import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/books.dart';
class CatalogScreen extends StatelessWidget {
  const CatalogScreen({super.key, this.genre});
  final String? genre;
  @override
  Widget build(BuildContext context) {
    final selected = genreNames.containsKey(genre) ? genre : null;
    final filtered = books.where((book) => selected == null || book.genre == selected).toList();
    return Scaffold(appBar: AppBar(title: const Text('Каталог бібліотеки')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: Wrap(spacing: 8, children: [
          ChoiceChip(label: const Text('Усі'), selected: selected == null,
            onSelected: (_) => context.go('/catalog')),
          for (final entry in genreNames.entries)
            ChoiceChip(key: ValueKey('genre-${entry.key}'), label: Text(entry.value),
              selected: selected == entry.key,
              onSelected: (_) => context.go(Uri(path: '/catalog',
                queryParameters: {'genre': entry.key}).toString())),
        ])),
        Expanded(child: ListView.builder(key: const PageStorageKey('catalog-scroll'),
          padding: const EdgeInsets.all(12), itemCount: filtered.length,
          itemBuilder: (context, index) {
            final book = filtered[index];
            return Card(child: ListTile(key: ValueKey('book-${book.id}'),
              leading: const Icon(Icons.auto_stories_outlined),
              title: Text(book.title), subtitle: Text('${book.author} · ${genreNames[book.genre]}'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => context.go(Uri(path: '/catalog/book/${book.id}',
                queryParameters: selected == null ? null : {'genre': selected}).toString())));
          })),
      ]));
  }
}
