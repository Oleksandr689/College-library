import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../state/library_state.dart';
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key, required this.store});
  final LibraryState store;
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}
class _ProfileScreenState extends State<ProfileScreen> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _card;
  bool _asking = false;
  bool get _dirty => _name.text != widget.store.name || _card.text != widget.store.card;
  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.store.name);
    _card = TextEditingController(text: widget.store.card);
    widget.store.profileExitGuard = _confirmDiscard;
  }
  @override
  void dispose() {
    widget.store.profileExitGuard = null;
    _name.dispose(); _card.dispose(); super.dispose();
  }
  Future<bool> _confirmDiscard() async {
    if (!_dirty) return true;
    if (_asking) return false;
    _asking = true;
    final discard = await showDialog<bool>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Незбережені зміни'),
      content: const Text('Вийти та відкинути зміни профілю?'),
      actions: [
        TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: const Text('Залишитися')),
        FilledButton(key: const ValueKey('discard-profile'),
          onPressed: () => Navigator.of(dialogContext).pop(true), child: const Text('Відкинути')),
      ]));
    if (!mounted) return false;
    _asking = false;
    if (discard != true) return false;
    setState(() { _name.text = widget.store.name; _card.text = widget.store.card; });
    return true;
  }
  Future<void> _back() async {
    final allowed = await _confirmDiscard();
    if (!mounted || !allowed) return;
    // PopScope має отримати canPop=true до повторного pop.
    await WidgetsBinding.instance.endOfFrame;
    if (!mounted) return;
    if (context.canPop()) { context.pop(); } else { context.go('/catalog'); }
  }
  void _save() {
    if (!_form.currentState!.validate()) return;
    setState(() {
      _name.text = _name.text.trim(); _card.text = _card.text.trim();
      widget.store.saveProfile(_name.text, _card.text);
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Профіль збережено')));
  }
  @override
  Widget build(BuildContext context) => PopScope<Object?>(canPop: !_dirty,
    onPopInvokedWithResult: (didPop, result) { if (!didPop) _back(); },
    child: Scaffold(appBar: AppBar(title: const Text('Профіль читача')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Form(key: _form, child: Column(children: [
          TextFormField(key: const ValueKey('profile-name'), controller: _name,
            decoration: const InputDecoration(labelText: 'Ім’я'), onChanged: (_) => setState(() {}),
            validator: (value) => value == null || value.trim().isEmpty ? 'Введіть ім’я' : null),
          const SizedBox(height: 12),
          TextFormField(key: const ValueKey('profile-card'), controller: _card,
            decoration: const InputDecoration(labelText: 'Квиток: LIB-001'),
            onChanged: (_) => setState(() {}),
            validator: (value) => RegExp(r'^LIB-\d{3,6}$').hasMatch(value?.trim() ?? '')
              ? null : 'Формат: LIB- та 3–6 цифр'),
          const SizedBox(height: 20),
          FilledButton(key: const ValueKey('save-profile'), onPressed: _save, child: const Text('Зберегти')),
          if (_dirty) const Text('Є незбережені зміни'),
        ])),
        const SizedBox(height: 24),
        AnimatedBuilder(animation: widget.store, builder: (context, _) => Column(children: [
          Text(widget.store.signedIn ? 'Вхід виконано' : 'Гостьовий режим'),
          TextButton(onPressed: widget.store.signedIn ? widget.store.logout
            : () => context.push<void>(Uri(path: '/login', queryParameters: {'from': '/profile'}).toString()),
            child: Text(widget.store.signedIn ? 'Вийти з облікового запису' : 'Увійти')),
        ])),
      ])));
}
