class Reservation {
  const Reservation({required this.bookId, required this.returnDate});
  final String bookId;
  final DateTime returnDate;
}
String dateLabel(DateTime date) => '${date.day.toString().padLeft(2, '0')}.'
  '${date.month.toString().padLeft(2, '0')}.${date.year}';
