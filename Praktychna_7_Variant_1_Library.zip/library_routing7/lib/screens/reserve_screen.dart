import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/books.dart';
import '../models/reservation.dart';
import '../state/library_state.dart';
import 'error_screen.dart';
class ReserveScreen extends StatefulWidget {
  const ReserveScreen({super.key, required this.bookId, required this.store});
  final String bookId;
  final LibraryState store;
  @override
  State<ReserveScreen> createState() => _ReserveScreenState();
}
class _ReserveScreenState extends State<ReserveScreen> {
  DateTime? _date;
  Future<void> _chooseDate() async {
    final location = Uri(path: '/catalog/book/${widget.bookId}/reserve/date',
      queryParameters: _date == null ? null : {'selected': _date!.toIso8601String()});
    final chosen = await context.push<DateTime>(location.toString());
    if (!mounted) return;
    if (chosen != null) setState(() => _date = chosen);
  }
  void _reserve() {
    if (_date == null) return;
    if (widget.store.reserve(widget.bookId, _date!)) {
      context.go('/my-books');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Не вдалося забронювати: перевірте дату, вхід або наявне бронювання.')));
    }
  }
  @override
  Widget build(BuildContext context) {
    final book = findBook(widget.bookId);
    if (book == null) return const ErrorScreen(message: 'Книгу не знайдено');
    return Scaffold(appBar: AppBar(title: const Text('Бронювання')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Text(book.title, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 24),
        Text(_date == null ? 'Дата повернення не обрана' : 'Повернути до ${dateLabel(_date!)}',
          key: const ValueKey('selected-date')),
        OutlinedButton(key: const ValueKey('choose-date'), onPressed: _chooseDate,
          child: const Text('Обрати дату повернення')),
        const SizedBox(height: 24),
        FilledButton(key: const ValueKey('confirm-reservation'), onPressed: _date == null ? null : _reserve,
          child: const Text('Підтвердити бронювання')),
      ]));
  }
}
