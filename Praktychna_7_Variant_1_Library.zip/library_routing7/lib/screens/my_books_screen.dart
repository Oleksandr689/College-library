import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/books.dart';
import '../models/reservation.dart';
import '../state/library_state.dart';
class MyBooksScreen extends StatelessWidget {
  const MyBooksScreen({super.key, required this.store});
  final LibraryState store;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Мої книги')),
    body: AnimatedBuilder(animation: store, builder: (context, _) {
      if (!store.signedIn) return const Center(child: Text('Увійдіть через вкладку «Профіль».'));
      if (store.reservations.isEmpty) return const Center(child: Text('Бронювань поки немає'));
      return ListView.builder(key: const PageStorageKey('reservations-scroll'),
        itemCount: store.reservations.length, itemBuilder: (context, index) {
          final item = store.reservations[index]; final book = findBook(item.bookId);
          return ListTile(title: Text(book?.title ?? 'Невідома книга'),
            subtitle: Text('Повернути до ${dateLabel(item.returnDate)}'),
            onTap: () => context.go('/catalog/book/${item.bookId}'));
        });
    }));
}
