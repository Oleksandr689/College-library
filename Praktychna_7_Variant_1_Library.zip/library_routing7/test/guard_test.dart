import 'package:flutter_test/flutter_test.dart';
import 'package:library_routing7/state/library_state.dart';
import 'package:library_routing7/state/route_guard.dart';
import 'package:library_routing7/data/books.dart';
void main() {
  test('guard preserves full original address and refreshes after login', () {
    final store = LibraryState();
    addTearDown(store.dispose);
    final target = Uri.parse('/catalog/book/15/reserve?genre=technology');
    final login = Uri.parse(libraryRedirect(store, target)!);
    expect(login.path, '/login');
    expect(login.queryParameters['from'], target.toString());
    var notifications = 0;
    store.addListener(() => notifications++);
    store.login();
    expect(notifications, 1);
    expect(libraryRedirect(store, login), target.toString());
    expect(libraryRedirect(store, target), isNull);
  });
  test('return address excludes external destinations and login loops', () {
    for (final invalid in ['https://example.com', '//example.com', '/login', '/other']) {
      expect(safeReturnLocation(invalid), '/catalog');
    }
    expect(safeReturnLocation('/catalog/book/1?genre=fiction'), '/catalog/book/1?genre=fiction');
  });
  test('custom scheme becomes an internal path without losing query', () {
    final store = LibraryState(); addTearDown(store.dispose);
    expect(libraryRedirect(store, Uri.parse('library://app/catalog/book/2?genre=fiction')),
      '/catalog/book/2?genre=fiction');
    expect(libraryRedirect(store, Uri.parse('library://other/catalog/book/2')), '/catalog');
  });
  test('18 unique books and reservations require login and valid date', () {
    expect(books.length, 18);
    expect(books.map((b) => b.id).toSet().length, 18);
    expect(findBook('missing'), isNull);
    final store = LibraryState(); addTearDown(store.dispose);
    final day = DateTime.now().add(const Duration(days: 14));
    expect(store.reserve('1', day), isFalse);
    store.login();
    expect(store.reserve('missing', day), isFalse);
    expect(store.reserve('1', DateTime.now()), isFalse);
    expect(store.reserve('1', day), isTrue);
    expect(store.reserve('1', day), isFalse);
    expect(store.reservations.length, 1);
  });
}
