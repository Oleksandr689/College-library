import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../state/library_state.dart';
class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key, required this.shell, required this.store});
  final StatefulNavigationShell shell;
  final LibraryState store;
  @override
  State<ShellScreen> createState() => _ShellScreenState();
}
class _ShellScreenState extends State<ShellScreen> {
  bool _switching = false;
  Future<void> _select(int index) async {
    if (_switching || index == widget.shell.currentIndex) return;
    _switching = true;
    if (widget.shell.currentIndex == 2) {
      final allowed = await widget.store.mayLeaveProfile();
      if (!mounted) return;
      if (!allowed) { _switching = false; return; }
    }
    widget.shell.goBranch(index); // Не скидаємо збережений стек гілки.
    _switching = false;
  }
  @override
  Widget build(BuildContext context) => Scaffold(body: widget.shell,
    bottomNavigationBar: NavigationBar(selectedIndex: widget.shell.currentIndex,
      onDestinationSelected: _select, destinations: const [
        NavigationDestination(key: ValueKey('tab-catalog'), icon: Icon(Icons.menu_book), label: 'Каталог'),
        NavigationDestination(key: ValueKey('tab-books'), icon: Icon(Icons.bookmark_outline), label: 'Мої книги'),
        NavigationDestination(key: ValueKey('tab-profile'), icon: Icon(Icons.person_outline), label: 'Профіль'),
      ]));
}
