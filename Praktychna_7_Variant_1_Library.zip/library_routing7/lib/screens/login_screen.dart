import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../state/library_state.dart';
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key, required this.store});
  final LibraryState store;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Вхід')),
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisSize: MainAxisSize.min, children: [
        const Text('Для бронювання потрібно увійти.'),
        const SizedBox(height: 12),
        const Text('Навчальний режим: один тестовий читач, без сервера та пароля.', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        FilledButton(key: const ValueKey('demo-login'), onPressed: store.login,
          child: const Text('Увійти як читач')),
        TextButton(onPressed: () => context.go('/catalog'), child: const Text('Повернутися до каталогу')),
      ],
    ))));
}
