package ua.edu.iot.library_routing7

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
