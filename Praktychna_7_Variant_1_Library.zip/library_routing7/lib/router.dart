import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'state/library_state.dart';
import 'state/route_guard.dart';
import 'screens/shell_screen.dart';
import 'screens/catalog_screen.dart';
import 'screens/book_screen.dart';
import 'screens/reserve_screen.dart';
import 'screens/return_date_screen.dart';
import 'screens/my_books_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/login_screen.dart';
import 'screens/error_screen.dart';

GoRouter createRouter(LibraryState store, {String? initialLocation}) {
  final root = GlobalKey<NavigatorState>(debugLabel: 'root');
  return GoRouter(
    navigatorKey: root,
    initialLocation: initialLocation ?? '/catalog',
    // За замовчуванням зовнішній platform deep link має пріоритет над initialLocation.
    refreshListenable: store,
    redirect: (_, state) => libraryRedirect(store, state.uri),
    errorBuilder: (_, state) => ErrorScreen(message: 'Невідома адреса: ${state.uri.path}'),
    routes: [
      GoRoute(path: '/login', builder: (_, _) => LoginScreen(store: store)),
      StatefulShellRoute.indexedStack(
        builder: (_, _, shell) => ShellScreen(shell: shell, store: store),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: '/catalog',
              builder: (_, state) => CatalogScreen(genre: state.uri.queryParameters['genre']),
              routes: [
                GoRoute(path: 'book/:bookId',
                  builder: (_, state) => BookScreen(bookId: state.pathParameters['bookId']!),
                  routes: [
                    GoRoute(path: 'reserve', parentNavigatorKey: root,
                      builder: (_, state) => ReserveScreen(
                        bookId: state.pathParameters['bookId']!, store: store),
                      routes: [
                        GoRoute(path: 'date', parentNavigatorKey: root,
                          builder: (_, state) => ReturnDateScreen(
                            initial: DateTime.tryParse(state.uri.queryParameters['selected'] ?? ''))),
                      ]),
                  ]),
              ]),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/my-books', builder: (_, _) => MyBooksScreen(store: store)),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: '/profile', builder: (_, _) => ProfileScreen(store: store),
              onExit: (_, _) => store.mayLeaveProfile()),
          ]),
        ]),
    ]);
}
