import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
class ReturnDateScreen extends StatefulWidget {
  const ReturnDateScreen({super.key, this.initial});
  final DateTime? initial;
  @override
  State<ReturnDateScreen> createState() => _ReturnDateScreenState();
}
class _ReturnDateScreenState extends State<ReturnDateScreen> {
  late final DateTime _today;
  late DateTime _selected;
  @override
  void initState() {
    super.initState();
    final now = DateTime.now(); _today = DateTime(now.year, now.month, now.day);
    final initial = widget.initial;
    _selected = initial != null && initial.isAfter(_today) &&
      !initial.isAfter(_today.add(const Duration(days: 60)))
        ? DateTime(initial.year, initial.month, initial.day) : _today.add(const Duration(days: 14));
  }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Дата повернення')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      CalendarDatePicker(initialDate: _selected,
        firstDate: _today.add(const Duration(days: 1)), lastDate: _today.add(const Duration(days: 60)),
        onDateChanged: (value) => setState(() => _selected = value)),
      FilledButton(key: const ValueKey('return-date'),
        onPressed: () => context.pop<DateTime>(_selected), child: const Text('Обрати дату')),
    ]));
}
