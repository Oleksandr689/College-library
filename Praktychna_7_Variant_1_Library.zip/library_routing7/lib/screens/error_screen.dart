import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
class ErrorScreen extends StatelessWidget {
  const ErrorScreen({super.key, required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Сторінку не знайдено')),
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisSize: MainAxisSize.min, children: [Text(message),
        const SizedBox(height: 20), FilledButton(onPressed: () => context.go('/catalog'),
          child: const Text('До каталогу')),
      ]))));
}
