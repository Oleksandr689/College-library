import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:library_routing7/router.dart';
import 'package:library_routing7/state/library_state.dart';

Future<GoRouter> start(WidgetTester tester, LibraryState store, String location) async {
  final router = createRouter(store, initialLocation: location);
  addTearDown(router.dispose);
  addTearDown(store.dispose);
  await tester.pumpWidget(MaterialApp.router(routerConfig: router));
  await tester.pumpAndSettle();
  return router;
}
void main() {
  testWidgets('direct book link builds catalogue underneath and tabs retain book', (tester) async {
    final router = await start(tester, LibraryState(), '/catalog/book/1');
    expect(find.text('Картка книги'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('tab-profile')));
    await tester.pumpAndSettle();
    expect(find.text('Профіль читача'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('tab-catalog')));
    await tester.pumpAndSettle();
    expect(find.text('Картка книги'), findsOneWidget);
    expect(router.canPop(), isTrue);
    router.pop();
    await tester.pumpAndSettle();
    expect(find.text('Каталог бібліотеки'), findsOneWidget);
  });
  testWidgets('guest booking login then date result and reservation', (tester) async {
    await start(tester, LibraryState(), '/catalog/book/1');
    await tester.tap(find.byKey(const ValueKey('reserve-book')));
    await tester.pumpAndSettle();
    expect(find.text('Для бронювання потрібно увійти.'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('demo-login')));
    await tester.pumpAndSettle();
    expect(find.text('Бронювання'), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
    await tester.tap(find.byKey(const ValueKey('choose-date')));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const ValueKey('return-date')));
    await tester.tap(find.byKey(const ValueKey('return-date')));
    await tester.pumpAndSettle();
    expect(find.textContaining('Повернути до'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('confirm-reservation')));
    await tester.pumpAndSettle();
    expect(find.text('Лісова пісня'), findsOneWidget);
    expect(find.textContaining('Повернути до'), findsOneWidget);
  });
  testWidgets('unsaved profile blocks branch change until discard', (tester) async {
    final store = LibraryState();
    await start(tester, store, '/profile');
    await tester.enterText(find.byKey(const ValueKey('profile-name')), 'Чернетка');
    await tester.tap(find.byKey(const ValueKey('tab-catalog')));
    await tester.pumpAndSettle();
    expect(find.text('Незбережені зміни'), findsOneWidget);
    await tester.tap(find.text('Залишитися'));
    await tester.pumpAndSettle();
    expect(find.text('Профіль читача'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('tab-catalog')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const ValueKey('discard-profile')));
    await tester.pumpAndSettle();
    expect(find.text('Каталог бібліотеки'), findsOneWidget);
    expect(store.name, 'Читач');
  });
  testWidgets('query filters books and unknown route uses errorBuilder', (tester) async {
    final router = await start(tester, LibraryState(), '/catalog?genre=technology');
    expect(find.text('Основи Dart'), findsOneWidget);
    expect(find.text('Лісова пісня'), findsNothing);
    router.go('/no-such-route');
    await tester.pumpAndSettle();
    expect(find.text('Сторінку не знайдено'), findsOneWidget);
    await tester.tap(find.text('До каталогу'));
    await tester.pumpAndSettle();
    expect(find.text('Каталог бібліотеки'), findsOneWidget);
  });
}
