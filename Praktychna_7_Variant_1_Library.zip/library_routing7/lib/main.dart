import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'router.dart';
import 'state/library_state.dart';
void main() => runApp(const LibraryApp());
class LibraryApp extends StatefulWidget {
  const LibraryApp({super.key});
  @override
  State<LibraryApp> createState() => _LibraryAppState();
}
class _LibraryAppState extends State<LibraryApp> {
  final _state = LibraryState();
  late final GoRouter _router = createRouter(_state);
  @override
  void dispose() { _router.dispose(); _state.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => MaterialApp.router(
    title: 'Бібліотека коледжу', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3F6663))),
    routerConfig: _router);
}
