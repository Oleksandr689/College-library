import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/books.dart';
import 'error_screen.dart';
class BookScreen extends StatelessWidget {
  const BookScreen({super.key, required this.bookId});
  final String bookId;
  @override
  Widget build(BuildContext context) {
    final book = findBook(bookId); // Не залежить від state.extra.
    if (book == null) return const ErrorScreen(message: 'Книгу не знайдено');
    return Scaffold(appBar: AppBar(title: const Text('Картка книги')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Text(book.title, key: const ValueKey('book-title'), style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 12), Text(book.author),
        const SizedBox(height: 8), Text(genreNames[book.genre]!),
        const SizedBox(height: 24), Text(book.description),
        const SizedBox(height: 24),
        FilledButton(key: const ValueKey('reserve-book'),
          onPressed: () {
            final query = GoRouterState.of(context).uri.queryParameters;
            context.push<void>(Uri(path: '/catalog/book/$bookId/reserve', queryParameters: query).toString());
          }, child: const Text('Забронювати')),
      ]));
  }
}
