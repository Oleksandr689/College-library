import 'library_state.dart';

String safeReturnLocation(String? value) {
  final uri = Uri.tryParse(value ?? '');
  if (uri == null || uri.hasScheme || uri.hasAuthority || !uri.path.startsWith('/') ||
      uri.path.startsWith('//') || uri.path.contains('..')) return '/catalog';
  if (!(uri.path == '/catalog' || uri.path.startsWith('/catalog/') ||
        uri.path == '/my-books' || uri.path == '/profile')) return '/catalog';
  return uri.toString();
}
String? libraryRedirect(LibraryState state, Uri uri) {
  if (uri.scheme == 'library') {
    if (uri.host != 'app') return '/catalog';
    return Uri(path: uri.path, query: uri.hasQuery ? uri.query : null).toString();
  }
  if (uri.path == '/') return '/catalog';
  final protected = RegExp(r'^/catalog/book/[^/]+/reserve(?:/date)?$').hasMatch(uri.path);
  if (protected && !state.signedIn) {
    return Uri(path: '/login', queryParameters: {'from': uri.toString()}).toString();
  }
  if (uri.path == '/login' && state.signedIn) {
    return safeReturnLocation(uri.queryParameters['from']);
  }
  return null;
}
