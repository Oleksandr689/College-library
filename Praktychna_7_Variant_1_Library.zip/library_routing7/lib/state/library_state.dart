import 'package:flutter/foundation.dart';
import '../models/reservation.dart';
import '../data/books.dart';
class LibraryState extends ChangeNotifier {
  bool _signedIn = false;
  String _name = 'Читач';
  String _card = 'LIB-001';
  final List<Reservation> _reservations = [];
  bool get signedIn => _signedIn;
  String get name => _name;
  String get card => _card;
  List<Reservation> get reservations => List.unmodifiable(_reservations);

  // Зв’язок із локальною формою: одна перевірка для вкладок і onExit маршруту.
  Future<bool> Function()? profileExitGuard;
  Future<bool> mayLeaveProfile() async => await profileExitGuard?.call() ?? true;

  void login() { _signedIn = true; notifyListeners(); }
  void logout() { _signedIn = false; notifyListeners(); }
  void saveProfile(String name, String card) {
    if (name.trim().isEmpty || !RegExp(r'^LIB-\d{3,6}$').hasMatch(card.trim())) {
      throw ArgumentError('Перевірте ім’я та номер квитка');
    }
    _name = name.trim(); _card = card.trim(); notifyListeners();
  }
  bool reserve(String bookId, DateTime date) {
    if (!_signedIn || findBook(bookId) == null) return false;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final day = DateTime(date.year, date.month, date.day);
    if (!day.isAfter(today) || day.isAfter(today.add(const Duration(days: 60)))) return false;
    if (_reservations.any((item) => item.bookId == bookId)) return false;
    _reservations.add(Reservation(bookId: bookId, returnDate: day));
    notifyListeners(); return true;
  }
}
